
public interface Animal {
	  
	//Interface methods
	public String getFullSn();
	
	public String getAnimalType();
	
	public String getDietType();
	
}
